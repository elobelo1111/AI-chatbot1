<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## ALBERT chatbot

- The streaming chat endpoint is a server route at `src/routes/api/chat.ts` calling `handleChat` in `src/lib/ai/chat.server.ts` (Lovable AI Gateway, `openai/gpt-6-astra` on Responses); keep model calls, the ALBERT system prompt and `LOVABLE_API_KEY` inside that server boundary, and `src/lib/ai/run-id.ts` beside it.
- Chat UI is built on AI Elements primitives in `src/components/ai-elements/`; do not replace them with hand-rolled transcript/composer primitives.
- Chat history is browser localStorage only (key `albert-chat-history`); assistant text inside the white window needs the `[--foreground:var(--card-foreground)]` remap on the chat wrapper to stay readable — do not remove it.
