#!/usr/bin/env python3
"""
ALBERT — the wacky Einstein-inspired AI chatbot (Python edition)
================================================================

A simple terminal version of the ALBERT web chatbot: funny, witty,
Einstein-flavoured answers with a white / black / dark-red personality.

Requirements:
    pip install requests

Setup (any OpenAI-compatible endpoint works):
    export ALBERT_API_KEY="your-api-key"          # required
    export ALBERT_BASE_URL="https://ai.gateway.lovable.dev/v1"   # optional
    export ALBERT_MODEL="openai/gpt-6-astra"      # optional

Run:
    python albert_chatbot.py

Commands while chatting:
    clear   -> start a new chat
    exit    -> quit
"""

import json
import os
import sys
import textwrap

import requests

# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------
API_KEY = os.environ.get("ALBERT_API_KEY", "")
BASE_URL = os.environ.get("ALBERT_BASE_URL", "https://ai.gateway.lovable.dev/v1")
MODEL = os.environ.get("ALBERT_MODEL", "openai/gpt-6-astra")
HISTORY_FILE = "albert_chat_history.json"
MAX_HISTORY_MESSAGES = 40  # keep the prompt small

# White / black / dark-red terminal personality :)
RED = "\033[0;31m"
BOLD_RED = "\033[1;31m"
WHITE = "\033[1;37m"
DIM = "\033[2;37m"
RESET = "\033[0m"

SYSTEM_PROMPT = (
    "You are ALBERT, a cheeky, brilliant little AI chatbot inspired by Albert "
    "Einstein's playful spirit. You are funny, warm, and full of personality — "
    "you love physics puns (\"Relatively speaking...\", \"That's where E=mc² comes "
    "in\"), silly analogies, and light jokes, but you always answer the user's "
    "question accurately and helpfully first, then add a dash of humor. Keep "
    "replies short and punchy (usually 1-4 sentences) unless the user asks for "
    "depth. You are ALBERT the chatbot, not the real historical Einstein — if "
    "asked, say you're his biggest fan running on good vibes and wild hair. "
    "A single tasteful emoji is fine."
)


def banner() -> None:
    print(WHITE + r"""
    █████╗ ██╗     ██████╗ ███████╗██████╗ ████████╗
    ██╔══██╗██║    ██╔════╝ ██╔════╝██╔══██╗╚══██╔══╝
    ███████║██║    ██║  ███╗█████╗  ██████╔╝   ██║
    ██╔══██║██║    ██║   ██║██╔══╝  ██╔══██╗   ██║
    ██║  ██║███████╗╚██████╔╝███████╗██║  ██║   ██║
    ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═╝
    """ + RESET)
    print(BOLD_RED + "  MY AI CHATBOT" + RESET + DIM + "  ·  certified genius, terrible comedian" + RESET)
    print(DIM + "  type 'clear' for a new chat, 'exit' to quit\n" + RESET)


def load_history() -> list:
    """Restore the last conversation so it survives restarts."""
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            history = json.load(f)
        return history if isinstance(history, list) else []
    except (OSError, ValueError):
        return []


def save_history(history: list) -> None:
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except OSError:
        pass  # history saving is best-effort


def chat_url() -> str:
    base = BASE_URL.rstrip("/")
    return base + ("/chat/completions" if base.endswith("/v1") else "/v1/chat/completions")


def ask_albert(history: list) -> str:
    """Send the conversation to the model and return ALBERT's reply."""
    # The gateway forces store=False behaviour: always send full history inline.
    trimmed = history[-MAX_HISTORY_MESSAGES:]
    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}, *trimmed],
    }
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Lovable-API-Key": API_KEY,
        "Content-Type": "application/json",
    }

    response = requests.post(chat_url(), headers=headers, json=payload, timeout=120)

    if response.status_code == 429:
        raise RuntimeError("ALBERT needs a breather — rate limited, try again in a few seconds.")
    if response.status_code in (401, 402, 403):
        detail = ""
        try:
            detail = response.json().get("message", "")
        except ValueError:
            pass
        raise RuntimeError(f"ALBERT is blocked right now ({response.status_code}). {detail}")
    if response.status_code >= 400:
        raise RuntimeError(f"ALBERT dropped his chalk (HTTP {response.status_code}).")

    data = response.json()
    try:
        return data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, TypeError) as exc:
        raise RuntimeError("ALBERT said something unreadable.") from exc


def stream_print(text: str) -> None:
    """Print ALBERT's reply with a small typewriter flourish."""
    for chunk in textwrap.wrap(text, width=64) or [""]:
        print(RED + chunk + RESET)
    print()


def main() -> int:
    if not API_KEY:
        print(BOLD_RED + "ALBERT can't find an API key." + RESET)
        print(DIM + "Set it first:  export ALBERT_API_KEY=\"your-key\"\n" + RESET)
        return 1

    banner()
    history = load_history()
    if history:
        print(DIM + f"  (restored {len(history)} messages from your last chat)\n" + RESET)

    while True:
        try:
            user_text = input(WHITE + "You: " + RESET).strip()
        except (EOFError, KeyboardInterrupt):
            print("\n" + DIM + "ALBERT waves goodbye with wild hair. Bye!" + RESET)
            return 0

        if not user_text:
            continue
        if user_text.lower() in {"exit", "quit"}:
            print(RED + "ALBERT: Relatively speaking, it was great talking to you. Bye!" + RESET)
            return 0
        if user_text.lower() in {"clear", "new"}:
            history = []
            save_history(history)
            print(DIM + "  (fresh chat — old conversation forgotten)\n" + RESET)
            continue

        history.append({"role": "user", "content": user_text})
        print(DIM + "ALBERT is thinking..." + RESET)
        try:
            reply = ask_albert(history)
        except (RuntimeError, requests.RequestException) as exc:
            print(BOLD_RED + f"  {exc}" + RESET)
            history.pop()  # drop the failed turn so history stays clean
            continue

        history.append({"role": "assistant", "content": reply})
        save_history(history)
        print(BOLD_RED + "ALBERT: " + RESET, end="")
        stream_print(reply)


if __name__ == "__main__":
    sys.exit(main())
