import { DefaultChatTransport, type UIMessage } from "ai";
import { useChat } from "@ai-sdk/react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Atom, PartyPopper } from "lucide-react";

import avatarUrl from "@/assets/albert-avatar.png";
import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import {
  Message,
  MessageContent,
  MessageResponse,
} from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputFooter,
  PromptInputSubmit,
  PromptInputTextarea,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "albert-chat-history";

function loadStoredMessages(): UIMessage[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as UIMessage[]) : [];
  } catch {
    return [];
  }
}

function persistMessages(messages: UIMessage[]) {
  if (typeof window === "undefined") return;
  try {
    if (messages.length === 0) {
      window.localStorage.removeItem(STORAGE_KEY);
    } else {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    }
  } catch {
    // Storage may be unavailable (private mode); chat still works in-session.
  }
}

export function AlbertChat() {
  const transport = useMemo(() => new DefaultChatTransport({ api: "/api/chat" }), []);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const [initialMessages] = useState(loadStoredMessages);

  const { messages, sendMessage, status, error, stop, setMessages } = useChat({
    id: "albert",
    transport,
    messages: initialMessages,
  });

  useEffect(() => {
    persistMessages(messages);
  }, [messages]);

  const busy = status === "submitted" || status === "streaming";

  const handleSubmit = async (message: { text?: string }) => {
    const text = (message.text ?? "").trim();
    if (!text || busy) return;
    await sendMessage({ text });
    textareaRef.current?.focus();
  };

  const handleClear = () => {
    if (busy) stop();
    setMessages([]);
    persistMessages([]);
    textareaRef.current?.focus();
  };

  return (
    <div className="flex h-full min-h-0 flex-col [--color-foreground:var(--color-card-foreground)] [--foreground:var(--card-foreground)]">
      <Conversation className="min-h-0 flex-1">
        <ConversationContent className="gap-6 px-4 py-6 sm:px-6">
          {messages.length === 0 ? (
            <ConversationEmptyState
              icon={<Atom className="size-10" />}
              title="Ask me anything!"
              description="I know relativity... and terrible jokes. Fair warning: both are unavoidable."
            />
          ) : (
            messages.map((message) => (
              <Message key={message.id} from={message.role}>
                {message.role === "assistant" ? (
                  <img
                    src={avatarUrl}
                    alt="ALBERT"
                    loading="lazy"
                    className="order-first size-8 shrink-0 rounded-full border-2 border-foreground bg-background"
                  />
                ) : null}
                <MessageContent
                  className={cn(
                    message.role === "user"
                      ? "rounded-2xl bg-primary px-4 py-3 text-base text-primary-foreground"
                      : "text-base text-card-foreground"
                  )}
                >
                  {message.parts.map((part, index) =>
                    part.type === "text" ? (
                      <MessageResponse key={index}>{part.text}</MessageResponse>
                    ) : null
                  )}
                </MessageContent>
              </Message>
            ))
          )}
          {status === "submitted" ? (
            <Message from="assistant">
              <img
                src={avatarUrl}
                alt="ALBERT thinking"
                loading="lazy"
                className="order-first size-8 shrink-0 rounded-full border-2 border-foreground bg-background"
              />
              <MessageContent className="rounded-2xl bg-secondary px-4 py-3 text-background">
                <Shimmer className="text-base font-medium">
                  ALBERT is thinking...
                </Shimmer>
              </MessageContent>
            </Message>
          ) : null}
        </ConversationContent>
        <ConversationScrollButton />
      </Conversation>

      {error ? (
        <div
          role="alert"
          className="mx-4 mb-2 rounded-lg border-2 border-destructive bg-destructive/10 px-3 py-2 text-sm text-destructive sm:mx-6"
        >
          {error.message.includes("402")
            ? "ALBERT is out of juice for today — the AI credits need a top-up."
            : error.message.includes("429")
              ? "ALBERT needs a breather. Try again in a few seconds."
              : "ALBERT dropped his chalk. Please try again."}
        </div>
      ) : null}

      <PromptInput
        onSubmit={handleSubmit}
        className="gap-2 border-t-2 border-foreground/10 bg-card p-3 sm:p-4"
      >
        <PromptInputTextarea
          ref={textareaRef}
          autoFocus
          placeholder="Ask ALBERT anything... (Enter to send)"
          rows={2}
          className="min-h-11 text-base"
        />
        <PromptInputFooter className="items-center justify-between">
          <button
            type="button"
            onClick={handleClear}
            disabled={messages.length === 0 && !busy}
            className="inline-flex items-center gap-1.5 rounded-md px-2 py-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground disabled:pointer-events-none disabled:opacity-50"
          >
            <PartyPopper className="size-3.5" />
            New chat
          </button>
          <PromptInputSubmit
            status={status}
            onStop={stop}
            className="size-11 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90"
          />
        </PromptInputFooter>
      </PromptInput>
    </div>
  );
}
