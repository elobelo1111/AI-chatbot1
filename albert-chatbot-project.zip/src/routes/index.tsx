import { createFileRoute, ClientOnly } from "@tanstack/react-router";

import { AlbertChat } from "@/components/albert-chat";
import avatarUrl from "@/assets/albert-avatar.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ALBERT — My AI Chatbot" },
      {
        name: "description",
        content:
          "Chat with ALBERT, a wacky Einstein-inspired AI chatbot. Ask anything, get witty answers.",
      },
      { property: "og:title", content: "ALBERT — My AI Chatbot" },
      {
        property: "og:description",
        content:
          "Chat with ALBERT, a wacky Einstein-inspired AI chatbot. Ask anything, get witty answers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "ALBERT — My AI Chatbot" },
      {
        name: "twitter:description",
        content:
          "Chat with ALBERT, a wacky Einstein-inspired AI chatbot. Ask anything, get witty answers.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="page-backdrop flex min-h-dvh items-center justify-center p-3 sm:p-6">
      <div className="flex h-[82dvh] max-h-[820px] min-h-[520px] w-full max-w-2xl flex-col overflow-hidden rounded-3xl border-2 border-foreground bg-card text-card-foreground shadow-[10px_10px_0_0_var(--color-primary)]">
        {/* Chat window header */}
        <header className="flex items-center gap-3 bg-foreground px-4 py-3 text-background sm:px-5">
          <img
            src={avatarUrl}
            alt="ALBERT avatar"
            width={1024}
            height={1024}
            className="albert-avatar size-12 shrink-0 rounded-full border-2 border-background bg-background"
          />
          <div className="min-w-0 flex-1">
            <h1 className="font-display text-2xl font-bold leading-none text-accent">
              ALBERT
            </h1>
            <p className="mt-1 truncate text-xs text-background/80">
              My AI Chatbot · certified genius, terrible comedian
            </p>
          </div>
          <span className="hidden rounded-full border border-background/30 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-background/80 sm:inline-block">
            E = mc² of fun
          </span>
        </header>

        {/* Chat body — browser-only (history comes from this browser's storage) */}
        <ClientOnly
          fallback={
            <div className="flex flex-1 items-center justify-center text-sm text-muted-foreground">
              Waking up ALBERT...
            </div>
          }
        >
          <AlbertChat />
        </ClientOnly>
      </div>
    </div>
  );
}
