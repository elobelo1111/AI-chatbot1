import { createOpenAI } from "@ai-sdk/openai";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { z } from "zod";

import {
  createLovableAiGatewayRunIdFetch,
  getLovableAiGatewayRunId,
  withLovableAiGatewayRunIdHeader,
} from "./run-id";

const LOVABLE_GATEWAY_URL = "https://ai.gateway.lovable.dev/v1";
const MODEL_ID = "openai/gpt-6-astra";

const SYSTEM_PROMPT = `You are ALBERT, a cheeky, brilliant little AI chatbot inspired by Albert Einstein's playful spirit. You are funny, warm, and full of personality — you love physics puns ("Relatively speaking...", "That's where E=mc² comes in"), silly analogies, and light jokes, but you always answer the user's question accurately and helpfully first, then add a dash of humor. Keep replies short and punchy (usually 1-4 sentences) unless the user asks for depth. Use a friendly, witty tone, never rude or sarcastic-mean. You are ALBERT the chatbot, not the real historical Einstein — if asked, say you're his biggest fan running on good vibes and wild hair. A single tasteful emoji is fine.`;

const requestSchema = z.object({
  messages: z
    .array(
      z.object({
        id: z.string().optional(),
        role: z.enum(["user", "assistant", "system"]),
        parts: z.array(z.unknown()).min(1),
        metadata: z.unknown().optional(),
      })
    )
    .min(1),
});

function jsonResponse(body: unknown, status: number) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}

export async function handleChat(request: Request) {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) {
    console.error("LOVABLE_API_KEY is missing");
    return jsonResponse({ error: "AI is not configured for this app." }, 500);
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonResponse({ error: "Invalid request body." }, 400);
  }

  const parsed = requestSchema.safeParse(body);
  if (!parsed.success) {
    return jsonResponse({ error: "Invalid chat messages payload." }, 400);
  }

  const messages = parsed.data.messages as unknown as UIMessage[];

  const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
  const provider = createOpenAI({
    baseURL: LOVABLE_GATEWAY_URL,
    apiKey,
    headers: {
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "vercel-ai-sdk",
    },
    fetch: runIdFetch.fetch,
  });

  const result = streamText({
    model: provider.responses(MODEL_ID),
    system: SYSTEM_PROMPT,
    messages: await convertToModelMessages(messages),
    abortSignal: request.signal,
    providerOptions: {
      openai: {
        store: false,
        forceReasoning: true,
        reasoningEffort: "low",
        reasoningSummary: "auto",
        include: ["reasoning.encrypted_content"],
      },
    },
  });

  return withLovableAiGatewayRunIdHeader(
    result.toUIMessageStreamResponse({ sendReasoning: true, originalMessages: messages }),
    runIdFetch
  );
}
